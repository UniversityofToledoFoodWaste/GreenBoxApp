# GreenBoxApp

This project is being developed by students for the GreenBox food collection system.



